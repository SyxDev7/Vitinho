// Global variables
let apps = [];
let currentCarouselPosition = { games: 0, programs: 0 };

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    loadApps();
    setupEventListeners();
    setupCarousels();
});

// Load apps from API
async function loadApps() {
    try {
        const response = await fetch('/api/apps');
        apps = await response.json();
        renderApps();
    } catch (error) {
        console.error('Error loading apps:', error);
    }
}

// Setup event listeners
function setupEventListeners() {
    // Modal close buttons
    document.querySelectorAll('.modal-close').forEach(btn => {
        btn.addEventListener('click', closeModals);
    });

    // Close modal when clicking outside
    document.querySelectorAll('.modal').forEach(modal => {
        modal.addEventListener('click', function(e) {
            if (e.target === this) {
                closeModals();
            }
        });
    });

    // Admin link
    document.querySelector('.admin-link').addEventListener('click', function(e) {
        e.preventDefault();
        showAdminLogin();
    });

    // Theme toggle
    document.querySelector('.theme-toggle').addEventListener('click', toggleTheme);

    // Search toggle
    document.querySelector('.search-toggle').addEventListener('click', toggleSearch);
}

// Setup carousel navigation
function setupCarousels() {
    // Games carousel
    document.getElementById('games-prev').addEventListener('click', () => {
        moveCarousel('games', -1);
    });
    document.getElementById('games-next').addEventListener('click', () => {
        moveCarousel('games', 1);
    });

    // Programs carousel
    document.getElementById('programs-prev').addEventListener('click', () => {
        moveCarousel('programs', -1);
    });
    document.getElementById('programs-next').addEventListener('click', () => {
        moveCarousel('programs', 1);
    });
}

// Move carousel
function moveCarousel(type, direction) {
    const track = document.getElementById(`${type}-track`);
    const cardWidth = 220; // 200px + 20px gap
    const visibleCards = Math.floor(track.parentElement.offsetWidth / cardWidth);
    const maxPosition = Math.max(0, track.children.length - visibleCards);
    
    currentCarouselPosition[type] += direction;
    
    if (currentCarouselPosition[type] < 0) {
        currentCarouselPosition[type] = 0;
    } else if (currentCarouselPosition[type] > maxPosition) {
        currentCarouselPosition[type] = maxPosition;
    }
    
    const translateX = -currentCarouselPosition[type] * cardWidth;
    track.style.transform = `translateX(${translateX}px)`;
}

// Render apps in different sections
function renderApps() {
    renderLatestGames();
    renderLatestPrograms();
    renderCategoryApps();
}

// Render latest games
function renderLatestGames() {
    const gamesTrack = document.getElementById('games-track');
    const gameApps = apps.filter(app => app.category !== 'Programas').slice(0, 10);
    
    gamesTrack.innerHTML = gameApps.map(app => createAppCard(app)).join('');
}

// Render latest programs
function renderLatestPrograms() {
    const programsTrack = document.getElementById('programs-track');
    const programApps = apps.filter(app => app.category === 'Programas').slice(0, 10);
    
    programsTrack.innerHTML = programApps.map(app => createAppCard(app)).join('');
}

// Render category apps
function renderCategoryApps() {
    const categories = ['action', 'race', 'simulation', 'sport', 'casual', 'strategy'];
    
    categories.forEach(category => {
        const container = document.getElementById(`${category}-apps`);
        if (container) {
            const categoryApps = apps.filter(app => 
                app.category.toLowerCase().includes(category) || 
                (category === 'action' && app.category === 'Ação') ||
                (category === 'race' && app.category === 'Corrida') ||
                (category === 'simulation' && app.category === 'Simulação') ||
                (category === 'sport' && app.category === 'Esporte') ||
                (category === 'casual' && app.category === 'Casual') ||
                (category === 'strategy' && app.category === 'Estratégia')
            ).slice(0, 6);
            
            container.innerHTML = categoryApps.map(app => createCategoryAppCard(app)).join('');
        }
    });
}

// Create app card for carousels
function createAppCard(app) {
    const rating = app.rating || 4.1;
    const ratingCount = app.rating_count || Math.floor(Math.random() * 10000) + 1000;
    const stars = createStarsHTML(rating);
    
    return `
        <div class="app-card" onclick="showAppDetail(${app.id})">
            <img src="${app.icon_url}" alt="${app.name}" class="app-icon" onerror="this.src='https://via.placeholder.com/80x80/4285f4/ffffff?text=APP'">
            <div class="app-badges">
                ${app.featured ? '<span class="app-badge badge-mod">MOD</span>' : ''}
                <span class="app-badge badge-offline">OFFLINE</span>
                <span class="app-badge badge-category">${app.category}</span>
            </div>
            <div class="app-name">${app.name}</div>
            <div class="app-developer">${app.developer || 'Desenvolvedor'}</div>
            <div class="app-rating">
                <div class="stars">${stars}</div>
                <span class="rating-text">${rating} (${ratingCount.toLocaleString()})</span>
            </div>
        </div>
    `;
}

// Create category app card
function createCategoryAppCard(app) {
    return `
        <a href="#" class="category-app" onclick="showAppDetail(${app.id}); return false;">
            <img src="${app.icon_url}" alt="${app.name}" class="category-app-icon" onerror="this.src='https://via.placeholder.com/60x60/4285f4/ffffff?text=APP'">
            <div class="category-app-name">${app.name}</div>
        </a>
    `;
}

// Create stars HTML
function createStarsHTML(rating) {
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);
    
    let starsHTML = '';
    
    for (let i = 0; i < fullStars; i++) {
        starsHTML += '<i class="fas fa-star star"></i>';
    }
    
    if (hasHalfStar) {
        starsHTML += '<i class="fas fa-star-half-alt star"></i>';
    }
    
    for (let i = 0; i < emptyStars; i++) {
        starsHTML += '<i class="far fa-star star empty"></i>';
    }
    
    return starsHTML;
}

// Show app detail modal
async function showAppDetail(appId) {
    try {
        const response = await fetch(`/api/apps/${appId}`);
        const app = await response.json();
        
        const modal = document.getElementById('app-modal');
        const modalBody = document.getElementById('modal-body');
        
        const screenshots = app.screenshots ? JSON.parse(app.screenshots) : [];
        const rating = app.rating || 4.1;
        const ratingCount = app.rating_count || Math.floor(Math.random() * 10000) + 1000;
        
        modalBody.innerHTML = `
            <div class="app-detail">
                <img src="${app.icon_url}" alt="${app.name}" class="app-detail-icon" onerror="this.src='https://via.placeholder.com/120x120/4285f4/ffffff?text=APP'">
                <div class="app-detail-info">
                    <h1>${app.name}</h1>
                    <div class="app-detail-developer">${app.developer || 'Desenvolvedor'}</div>
                    <div class="app-detail-meta">
                        <span><i class="fas fa-android"></i> Android 7.0+</span>
                        <span><i class="fas fa-tag"></i> Versão: ${app.version}</span>
                        <span><i class="fas fa-download"></i> 134.9Mb</span>
                    </div>
                    <div class="app-detail-rating">
                        <div class="stars">${createStarsHTML(rating)}</div>
                        <span>${rating} (${ratingCount.toLocaleString()})</span>
                    </div>
                    <div class="app-badges">
                        ${app.featured ? '<span class="app-badge badge-mod">MOD</span>' : ''}
                        <span class="app-badge badge-offline">OFFLINE</span>
                        <span class="app-badge badge-category">${app.category}</span>
                    </div>
                </div>
                <button class="download-btn" onclick="showDownloadPage(${app.id})">
                    <i class="fas fa-download"></i>
                    DOWNLOAD (134.9MB)
                </button>
            </div>
            
            <div class="app-description">
                <p>${app.description}</p>
            </div>
            
            ${screenshots.length > 0 ? `
                <div class="screenshots-section">
                    <h3>Screenshots</h3>
                    <div class="screenshots-grid">
                        ${screenshots.map(screenshot => `
                            <img src="${screenshot}" alt="Screenshot" class="screenshot" onerror="this.src='https://via.placeholder.com/200x300/f0f0f0/333?text=Screenshot'">
                        `).join('')}
                    </div>
                </div>
            ` : ''}
        `;
        
        modal.style.display = 'block';
        document.body.style.overflow = 'hidden';
    } catch (error) {
        console.error('Error loading app details:', error);
    }
}

// Show download page
function showDownloadPage(appId) {
    const app = apps.find(a => a.id === appId);
    if (!app) return;
    
    closeModals();
    
    const modal = document.getElementById('download-modal');
    const modalBody = document.getElementById('download-modal-body');
    
    modalBody.innerHTML = `
        <div class="download-page">
            <img src="${app.icon_url}" alt="${app.name}" class="download-app-icon" onerror="this.src='https://via.placeholder.com/120x120/4285f4/ffffff?text=APP'">
            <div class="download-app-name">${app.name}</div>
            <div class="download-app-version">Versão ${app.version}</div>
            <div class="download-app-meta">
                <i class="fas fa-android"></i> Android 7.0+
            </div>
            
            <div class="download-timer" id="download-timer">6</div>
            
            <button class="play-pc-btn">
                <i class="fas fa-desktop"></i>
                PLAY ON PC
            </button>
            
            <div class="similar-games">
                <h3>Jogos similares a ${app.name}:</h3>
                <div class="similar-games-grid" id="similar-games-grid">
                    <!-- Similar games will be loaded here -->
                </div>
            </div>
        </div>
    `;
    
    modal.style.display = 'block';
    document.body.style.overflow = 'hidden';
    
    // Start download timer
    startDownloadTimer(app);
    
    // Load similar games
    loadSimilarGames(app);
}

// Start download timer
function startDownloadTimer(app) {
    let timeLeft = 6;
    const timerElement = document.getElementById('download-timer');
    
    const timer = setInterval(() => {
        timeLeft--;
        timerElement.textContent = timeLeft;
        
        // Update progress circle
        const progress = ((6 - timeLeft) / 6) * 360;
        timerElement.style.background = `conic-gradient(#28a745 ${progress}deg, #e9ecef ${progress}deg)`;
        
        if (timeLeft <= 0) {
            clearInterval(timer);
            // Simulate download
            downloadApp(app);
        }
    }, 1000);
}

// Simulate app download
function downloadApp(app) {
    // Record download
    fetch(`/api/apps/${app.id}/download`, { method: 'POST' });
    
    // Create download link
    const link = document.createElement('a');
    link.href = app.download_url || '#';
    link.download = `${app.name}.apk`;
    link.click();
    
    // Show success message
    const timerElement = document.getElementById('download-timer');
    timerElement.innerHTML = '<i class="fas fa-check"></i>';
    timerElement.style.background = '#28a745';
}

// Load similar games
function loadSimilarGames(app) {
    const similarApps = apps
        .filter(a => a.id !== app.id && a.category === app.category)
        .slice(0, 8);
    
    const container = document.getElementById('similar-games-grid');
    container.innerHTML = similarApps.map(similarApp => `
        <a href="#" class="similar-game" onclick="showAppDetail(${similarApp.id}); return false;">
            <img src="${similarApp.icon_url}" alt="${similarApp.name}" class="similar-game-icon" onerror="this.src='https://via.placeholder.com/60x60/4285f4/ffffff?text=APP'">
            <div class="similar-game-name">${similarApp.name}</div>
        </a>
    `).join('');
}

// Close all modals
function closeModals() {
    document.querySelectorAll('.modal').forEach(modal => {
        modal.style.display = 'none';
    });
    document.body.style.overflow = 'auto';
}

// Show admin login
function showAdminLogin() {
    const modal = document.getElementById('app-modal');
    const modalBody = document.getElementById('modal-body');
    
    modalBody.innerHTML = `
        <div style="text-align: center; padding: 40px 20px;">
            <h2 style="margin-bottom: 30px;">Login Administrativo</h2>
            <form id="admin-login-form" style="max-width: 300px; margin: 0 auto;">
                <div style="margin-bottom: 20px;">
                    <label style="display: block; margin-bottom: 5px; text-align: left;">Usuário:</label>
                    <input type="text" id="admin-username" required style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px;">
                </div>
                <div style="margin-bottom: 30px;">
                    <label style="display: block; margin-bottom: 5px; text-align: left;">Senha:</label>
                    <input type="password" id="admin-password" required style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px;">
                </div>
                <button type="submit" style="width: 100%; padding: 12px; background: #007bff; color: white; border: none; border-radius: 4px; font-weight: bold; cursor: pointer;">
                    Entrar
                </button>
            </form>
        </div>
    `;
    
    modal.style.display = 'block';
    document.body.style.overflow = 'hidden';
    
    // Handle admin login
    document.getElementById('admin-login-form').addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const username = document.getElementById('admin-username').value;
        const password = document.getElementById('admin-password').value;
        
        try {
            const response = await fetch('/api/admin/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ username, password })
            });
            
            if (response.ok) {
                const result = await response.json();
                showAdminPanel();
            } else {
                alert('Credenciais inválidas');
            }
        } catch (error) {
            console.error('Error during login:', error);
            alert('Erro ao fazer login');
        }
    });
}

// Show admin panel
async function showAdminPanel() {
    try {
        const response = await fetch('/api/admin/stats');
        const stats = await response.json();
        
        const modal = document.getElementById('app-modal');
        const modalBody = document.getElementById('modal-body');
        
        modalBody.innerHTML = `
            <div style="text-align: center; padding: 40px 20px;">
                <h2 style="margin-bottom: 30px;">Painel Administrativo</h2>
                
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 20px; margin-bottom: 30px;">
                    <div style="background: #f8f9fa; padding: 20px; border-radius: 8px;">
                        <div style="font-size: 24px; font-weight: bold; color: #007bff;">${stats.total_apps}</div>
                        <div style="color: #6c757d;">Total de Apps</div>
                    </div>
                    <div style="background: #f8f9fa; padding: 20px; border-radius: 8px;">
                        <div style="font-size: 24px; font-weight: bold; color: #28a745;">${stats.total_downloads}</div>
                        <div style="color: #6c757d;">Total de Downloads</div>
                    </div>
                    <div style="background: #f8f9fa; padding: 20px; border-radius: 8px;">
                        <div style="font-size: 24px; font-weight: bold; color: #ffc107;">${stats.total_comments}</div>
                        <div style="color: #6c757d;">Total de Comentários</div>
                    </div>
                    <div style="background: #f8f9fa; padding: 20px; border-radius: 8px;">
                        <div style="font-size: 24px; font-weight: bold; color: #dc3545;">${stats.pending_comments}</div>
                        <div style="color: #6c757d;">Comentários Pendentes</div>
                    </div>
                </div>
                
                <p style="color: #6c757d; margin-bottom: 20px;">
                    Funcionalidades administrativas completas estarão disponíveis em breve.
                </p>
                
                <button onclick="logout()" style="padding: 10px 20px; background: #6c757d; color: white; border: none; border-radius: 4px; cursor: pointer;">
                    Sair
                </button>
            </div>
        `;
    } catch (error) {
        console.error('Error loading admin stats:', error);
    }
}

// Logout
async function logout() {
    try {
        await fetch('/api/admin/logout', { method: 'POST' });
        closeModals();
    } catch (error) {
        console.error('Error during logout:', error);
    }
}

// Toggle theme
function toggleTheme() {
    document.body.classList.toggle('dark-theme');
    const isDark = document.body.classList.contains('dark-theme');
    localStorage.setItem('darkTheme', isDark);
}

// Toggle search
function toggleSearch() {
    // Implement search functionality
    console.log('Search functionality to be implemented');
}

// Load saved theme
function loadSavedTheme() {
    const savedTheme = localStorage.getItem('darkTheme');
    if (savedTheme === 'true') {
        document.body.classList.add('dark-theme');
    }
}

// Initialize theme on load
loadSavedTheme();

// Smooth scrolling for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth'
            });
        }
    });
});

// Add loading states
function showLoading(element) {
    element.innerHTML = '<div class="loading"></div>';
}

// Add fade-in animation to elements
function addFadeInAnimation() {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('fade-in');
            }
        });
    });

    document.querySelectorAll('.app-card, .category-block').forEach(el => {
        observer.observe(el);
    });
}

