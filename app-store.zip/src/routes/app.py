from flask import Blueprint, request, jsonify
from src.models.app import App, db
from src.models.comment import Comment
import json

app_bp = Blueprint('app', __name__)

@app_bp.route('/apps', methods=['GET'])
def get_apps():
    """Listar todos os aplicativos com filtros opcionais"""
    try:
        category = request.args.get('category')
        featured = request.args.get('featured')
        search = request.args.get('search')
        
        query = App.query
        
        if category:
            query = query.filter(App.category == category)
        
        if featured:
            query = query.filter(App.featured == (featured.lower() == 'true'))
        
        if search:
            query = query.filter(App.name.contains(search))
        
        apps = query.order_by(App.created_at.desc()).all()
        
        return jsonify({
            'success': True,
            'apps': [app.to_dict() for app in apps]
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app_bp.route('/apps/<int:app_id>', methods=['GET'])
def get_app(app_id):
    """Obter detalhes de um aplicativo específico"""
    try:
        app = App.query.get_or_404(app_id)
        
        # Obter comentários aprovados para este app
        comments = Comment.query.filter_by(app_id=app_id, approved=True).order_by(Comment.created_at.desc()).all()
        
        app_data = app.to_dict()
        app_data['comments'] = [comment.to_dict() for comment in comments]
        
        return jsonify({
            'success': True,
            'app': app_data
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app_bp.route('/apps/<int:app_id>/download', methods=['POST'])
def download_app(app_id):
    """Incrementar contador de downloads"""
    try:
        app = App.query.get_or_404(app_id)
        app.downloads_count += 1
        db.session.commit()
        
        return jsonify({
            'success': True,
            'download_url': app.download_url,
            'downloads_count': app.downloads_count
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app_bp.route('/categories', methods=['GET'])
def get_categories():
    """Obter todas as categorias disponíveis"""
    try:
        categories = db.session.query(App.category).distinct().all()
        category_list = [category[0] for category in categories]
        
        return jsonify({
            'success': True,
            'categories': category_list
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app_bp.route('/apps/<int:app_id>/comments', methods=['POST'])
def add_comment(app_id):
    """Adicionar um comentário a um aplicativo"""
    try:
        data = request.get_json()
        
        if not data or not data.get('author_name') or not data.get('content'):
            return jsonify({
                'success': False,
                'error': 'Nome do autor e conteúdo são obrigatórios'
            }), 400
        
        # Verificar se o app existe
        app = App.query.get_or_404(app_id)
        
        comment = Comment(
            app_id=app_id,
            author_name=data['author_name'],
            author_email=data.get('author_email'),
            content=data['content'],
            rating=data.get('rating')
        )
        
        db.session.add(comment)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'comment': comment.to_dict()
        }), 201
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

