from src.models.user import db
from datetime import datetime
import json

class App(db.Model):
    __tablename__ = 'apps'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=False)
    version = db.Column(db.String(20), nullable=False)
    category = db.Column(db.String(50), nullable=False)
    developer = db.Column(db.String(100), nullable=True)
    download_url = db.Column(db.String(255), nullable=False)
    icon_url = db.Column(db.String(255), nullable=False)
    screenshots = db.Column(db.Text, nullable=True)  # JSON string
    featured = db.Column(db.Boolean, default=False)
    downloads = db.Column(db.Integer, default=0)
    rating = db.Column(db.Float, default=4.1)
    rating_count = db.Column(db.Integer, default=0)
    file_size = db.Column(db.String(20), default='134.9MB')
    android_version = db.Column(db.String(20), default='7.0+')
    price = db.Column(db.String(10), default='$0')
    installs = db.Column(db.String(20), default='100 000 000+')
    age_rating = db.Column(db.String(10), default='3+ years')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    comments = db.relationship('Comment', backref='app', lazy=True, cascade='all, delete-orphan')
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'version': self.version,
            'category': self.category,
            'developer': self.developer,
            'download_url': self.download_url,
            'icon_url': self.icon_url,
            'screenshots': self.screenshots,
            'featured': self.featured,
            'downloads': self.downloads,
            'rating': self.rating,
            'rating_count': self.rating_count,
            'file_size': self.file_size,
            'android_version': self.android_version,
            'price': self.price,
            'installs': self.installs,
            'age_rating': self.age_rating,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
    
    def get_screenshots_list(self):
        if self.screenshots:
            try:
                return json.loads(self.screenshots)
            except:
                return []
        return []
    
    def set_screenshots_list(self, screenshots_list):
        self.screenshots = json.dumps(screenshots_list) if screenshots_list else None

