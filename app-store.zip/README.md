# AppStore - Loja de Aplicativos Personalizada

Uma loja de aplicativos completa desenvolvida em Python/Flask com design moderno inspirado na App Store do iPhone.

## 🚀 Características

- **Design Profissional**: Interface moderna e responsiva similar à App Store
- **Sistema Completo**: Frontend e backend integrados
- **Painel Administrativo**: Gerenciamento completo de aplicativos
- **Sistema de Comentários**: Avaliações e feedback dos usuários
- **Busca e Filtros**: Encontre aplicativos por nome, categoria ou destaques
- **Banco de Dados SQLite**: Armazenamento local eficiente
- **API RESTful**: Endpoints organizados para todas as funcionalidades

## 📋 Pré-requisitos

- Python 3.11+
- pip (gerenciador de pacotes Python)
- Navegador web moderno

## 🛠️ Instalação e Configuração

### 1. Clone ou baixe o projeto
```bash
cd app-store
```

### 2. Ative o ambiente virtual
```bash
source venv/bin/activate
```

### 3. Instale as dependências
```bash
pip install -r requirements.txt
```

### 4. Configure o banco de dados
```bash
python -c "
from src.main import app
from src.models.user import db
from src.models.app import App
from src.models.admin import Admin
from src.models.comment import Comment
import json

with app.app_context():
    # Criar administrador padrão
    admin = Admin.query.filter_by(username='admin').first()
    if not admin:
        admin = Admin(username='admin', email='admin@appstore.com')
        admin.set_password('admin123')
        db.session.add(admin)
        print('Admin criado: admin / admin123')
    
    # Criar app de exemplo (opcional)
    if App.query.count() == 0:
        app_obj = App(
            name='PhotoEditor Pro',
            description='Editor de fotos profissional com recursos avançados',
            version='2.1.0',
            category='Fotografia',
            download_url='https://example.com/downloads/photoeditor-pro.zip',
            icon_url='https://via.placeholder.com/128x128/4285f4/ffffff?text=PE',
            screenshots=json.dumps(['https://via.placeholder.com/400x600/f0f0f0/333?text=Screenshot+1']),
            featured=True
        )
        db.session.add(app_obj)
        print('App de exemplo criado')
    
    db.session.commit()
    print('Configuração concluída!')
"
```

### 5. Execute o servidor
```bash
python src/main.py
```

O site estará disponível em: http://localhost:5000

## 🎯 Como Usar

### Para Usuários

1. **Navegar**: Explore aplicativos na página inicial
2. **Buscar**: Use a barra de busca para encontrar aplicativos específicos
3. **Filtrar**: Use os filtros por categoria ou destaques
4. **Detalhes**: Clique em qualquer aplicativo para ver detalhes completos
5. **Download**: Clique no botão "Download" para baixar aplicativos
6. **Comentar**: Deixe avaliações e comentários nos aplicativos

### Para Administradores

1. **Acesso**: Clique em "Admin" no menu superior
2. **Login**: Use as credenciais padrão:
   - Usuário: `admin`
   - Senha: `admin123`
3. **Painel**: Visualize estatísticas do sistema
4. **Gerenciar**: Use as APIs para adicionar/editar aplicativos

## 🔧 APIs Disponíveis

### Aplicativos
- `GET /api/apps` - Listar todos os aplicativos
- `GET /api/apps/{id}` - Detalhes de um aplicativo
- `POST /api/apps/{id}/download` - Registrar download
- `POST /api/apps/{id}/comments` - Adicionar comentário

### Administração
- `POST /api/admin/login` - Login administrativo
- `POST /api/admin/logout` - Logout
- `POST /api/admin/apps` - Criar aplicativo
- `PUT /api/admin/apps/{id}` - Atualizar aplicativo
- `DELETE /api/admin/apps/{id}` - Deletar aplicativo
- `GET /api/admin/stats` - Estatísticas do sistema

### Categorias
- `GET /api/categories` - Listar categorias disponíveis

## 📁 Estrutura do Projeto

```
app-store/
├── src/
│   ├── models/          # Modelos do banco de dados
│   │   ├── user.py      # Modelo base
│   │   ├── app.py       # Modelo de aplicativos
│   │   ├── admin.py     # Modelo de administradores
│   │   └── comment.py   # Modelo de comentários
│   ├── routes/          # Rotas da API
│   │   ├── user.py      # Rotas de usuários
│   │   ├── app.py       # Rotas de aplicativos
│   │   └── admin.py     # Rotas administrativas
│   ├── static/          # Arquivos estáticos
│   │   ├── index.html   # Página principal
│   │   ├── styles.css   # Estilos CSS
│   │   └── script.js    # JavaScript
│   ├── database/        # Banco de dados SQLite
│   └── main.py          # Aplicação principal
├── venv/                # Ambiente virtual Python
├── requirements.txt     # Dependências
└── README.md           # Esta documentação
```

## 🚀 Deploy em VPS

### 1. Preparar o servidor
```bash
# Atualizar sistema
sudo apt update && sudo apt upgrade -y

# Instalar Python e dependências
sudo apt install python3 python3-pip python3-venv nginx -y
```

### 2. Transferir arquivos
```bash
# Copie todos os arquivos do projeto para sua VPS
scp -r app-store/ usuario@seu-servidor:/var/www/
```

### 3. Configurar aplicação
```bash
cd /var/www/app-store
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### 4. Configurar Nginx (opcional)
```nginx
server {
    listen 80;
    server_name seu-dominio.com;
    
    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

### 5. Executar em produção
```bash
# Para desenvolvimento
python src/main.py

# Para produção (recomendado)
pip install gunicorn
gunicorn -w 4 -b 0.0.0.0:5000 src.main:app
```

## 🔒 Segurança

- Altere a `SECRET_KEY` em `src/main.py` para produção
- Altere as credenciais do administrador padrão
- Configure HTTPS em produção
- Use um servidor de banco de dados robusto para produção (PostgreSQL, MySQL)

## 🎨 Personalização

### Cores e Estilos
Edite as variáveis CSS em `src/static/styles.css`:
```css
:root {
    --primary-color: #007AFF;    /* Cor principal */
    --accent-color: #FF3B30;     /* Cor de destaque */
    --background-color: #F2F2F7; /* Cor de fundo */
}
```

### Adicionar Aplicativos
Use a API administrativa ou adicione diretamente no banco:
```python
app_obj = App(
    name='Seu Aplicativo',
    description='Descrição detalhada',
    version='1.0.0',
    category='Categoria',
    download_url='https://link-download.com',
    icon_url='https://link-icone.com',
    featured=True
)
```

## 📞 Suporte

Para dúvidas ou problemas:
1. Verifique os logs do servidor
2. Confirme se todas as dependências estão instaladas
3. Verifique se o banco de dados foi criado corretamente

## 📄 Licença

Este projeto foi desenvolvido como uma solução personalizada para hospedar aplicativos da sua equipe.

---

**Desenvolvido com ❤️ em Python/Flask**

