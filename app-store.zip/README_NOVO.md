# AN1 Clone - Loja de Aplicativos

## 🎯 Visão Geral

Este projeto é um clone completo do site AN1.com, desenvolvido em Python/Flask para hospedar aplicativos Android com painel administrativo. O site replica fielmente o layout e funcionalidades do AN1.com original.

## ✨ Características Principais

### 🎨 Design Fiel ao AN1.com
- **Header com abas coloridas**: Home, Games, Programs, News, Articles, FAQ
- **Banner dividido**: Catálogo de Jogos (verde) e Jogos MOD (laranja)
- **Carrossel horizontal**: Para últimos jogos e programas
- **Cards de aplicativos**: Com ícone, nome, desenvolvedor, avaliações por estrelas
- **Categorias organizadas**: Action, Race, Simulations, Sport, Casual, Strategy
- **Sistema de badges**: MOD, OFFLINE, categoria

### 🔧 Funcionalidades Implementadas
- **Página inicial**: Layout idêntico ao AN1.com com carrosséis e categorias
- **Página de detalhes**: Modal com informações completas do aplicativo
- **Página de download**: Timer de 6 segundos e jogos similares
- **Sistema de comentários**: Com avaliações por estrelas
- **Painel administrativo**: Login seguro e estatísticas
- **APIs RESTful**: Para todas as funcionalidades
- **Banco de dados SQLite**: Para armazenar aplicativos, comentários e admins

### 📱 Responsividade
- Design totalmente responsivo
- Compatível com desktop e mobile
- Navegação touch-friendly

## 🚀 Instalação e Configuração

### Pré-requisitos
- Python 3.11+
- pip (gerenciador de pacotes Python)

### Instalação
```bash
# 1. Extrair o projeto
unzip app-store-completo.zip
cd app-store

# 2. Ativar ambiente virtual
source venv/bin/activate

# 3. Instalar dependências (já incluídas no venv)
pip install -r requirements.txt

# 4. Inicializar banco de dados (já criado)
# O banco já está configurado com dados de exemplo

# 5. Executar o servidor
python src/main.py
```

### Acesso
- **Site**: http://localhost:5000
- **Admin**: Clique em "Admin" no menu
  - Usuário: `admin`
  - Senha: `admin123`

## 📁 Estrutura do Projeto

```
app-store/
├── src/
│   ├── main.py                 # Aplicação principal Flask
│   ├── models/                 # Modelos do banco de dados
│   │   ├── user.py            # Configuração do SQLAlchemy
│   │   ├── app.py             # Modelo de aplicativos
│   │   ├── comment.py         # Modelo de comentários
│   │   └── admin.py           # Modelo de administradores
│   ├── routes/                # Rotas da API
│   │   ├── app.py             # Rotas de aplicativos
│   │   └── admin.py           # Rotas administrativas
│   ├── static/                # Frontend
│   │   ├── index.html         # Página principal
│   │   ├── styles.css         # Estilos CSS
│   │   └── script.js          # JavaScript
│   └── database/              # Banco de dados
│       └── app.db             # SQLite database
├── venv/                      # Ambiente virtual Python
├── requirements.txt           # Dependências
└── README.md                  # Documentação
```

## 🔧 Deploy na VPS

### 1. Preparação da VPS
```bash
# Atualizar sistema
sudo apt update && sudo apt upgrade -y

# Instalar Python e dependências
sudo apt install python3 python3-pip python3-venv nginx -y

# Criar usuário para a aplicação
sudo useradd -m -s /bin/bash appstore
sudo su - appstore
```

### 2. Upload e Configuração
```bash
# Fazer upload do projeto para /home/appstore/
# Extrair e configurar
cd /home/appstore/
unzip app-store-completo.zip
cd app-store

# Ativar ambiente virtual
source venv/bin/activate

# Testar aplicação
python src/main.py
```

### 3. Configuração do Gunicorn
```bash
# Instalar Gunicorn
pip install gunicorn

# Criar arquivo de serviço
sudo nano /etc/systemd/system/appstore.service
```

Conteúdo do arquivo de serviço:
```ini
[Unit]
Description=App Store Flask Application
After=network.target

[Service]
User=appstore
Group=appstore
WorkingDirectory=/home/appstore/app-store
Environment="PATH=/home/appstore/app-store/venv/bin"
ExecStart=/home/appstore/app-store/venv/bin/gunicorn --workers 3 --bind 0.0.0.0:5000 src.main:app
Restart=always

[Install]
WantedBy=multi-user.target
```

### 4. Configuração do Nginx
```bash
# Criar configuração do site
sudo nano /etc/nginx/sites-available/appstore
```

Conteúdo da configuração:
```nginx
server {
    listen 80;
    server_name seu-dominio.com;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    location /static {
        alias /home/appstore/app-store/src/static;
        expires 30d;
    }
}
```

### 5. Ativar Serviços
```bash
# Ativar site no Nginx
sudo ln -s /etc/nginx/sites-available/appstore /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx

# Ativar serviço da aplicação
sudo systemctl enable appstore
sudo systemctl start appstore
sudo systemctl status appstore
```

## 👨‍💼 Painel Administrativo

### Acesso
1. Acesse o site
2. Clique em "Admin" no menu superior
3. Use as credenciais:
   - **Usuário**: admin
   - **Senha**: admin123

### Funcionalidades Disponíveis
- **Estatísticas**: Total de apps, downloads, comentários
- **Gerenciamento**: Funcionalidades completas em desenvolvimento
- **Segurança**: Sistema de login com hash de senhas

### Adicionando Novos Administradores
```python
# Via Python shell
from src.main import app
from src.models.user import db
from src.models.admin import Admin

with app.app_context():
    admin = Admin(username='novo_admin', email='admin@email.com')
    admin.set_password('senha_segura')
    db.session.add(admin)
    db.session.commit()
```

## 📊 Banco de Dados

### Estrutura das Tabelas

#### Apps
- `id`: ID único
- `name`: Nome do aplicativo
- `description`: Descrição completa
- `version`: Versão atual
- `category`: Categoria (Ação, Simulação, etc.)
- `developer`: Desenvolvedor
- `download_url`: URL de download
- `icon_url`: URL do ícone
- `screenshots`: JSON com capturas de tela
- `featured`: Se é destaque (MOD)
- `rating`: Avaliação (1-5)
- `rating_count`: Número de avaliações
- `file_size`: Tamanho do arquivo
- `downloads`: Contador de downloads

#### Comments
- `id`: ID único
- `app_id`: ID do aplicativo
- `author_name`: Nome do autor
- `author_email`: Email do autor
- `content`: Conteúdo do comentário
- `rating`: Avaliação (1-5 estrelas)
- `approved`: Se foi aprovado
- `created_at`: Data de criação

#### Admins
- `id`: ID único
- `username`: Nome de usuário
- `email`: Email
- `password_hash`: Hash da senha
- `created_at`: Data de criação

### Adicionando Aplicativos
```python
# Via Python shell
from src.main import app
from src.models.user import db
from src.models.app import App
import json

with app.app_context():
    novo_app = App(
        name='Nome do App',
        description='Descrição detalhada...',
        version='1.0.0',
        category='Ação',
        developer='Desenvolvedor',
        download_url='https://exemplo.com/app.apk',
        icon_url='https://exemplo.com/icon.png',
        screenshots=json.dumps([
            'https://exemplo.com/screenshot1.png',
            'https://exemplo.com/screenshot2.png'
        ]),
        featured=True,  # Para apps MOD
        rating=4.5,
        rating_count=1000
    )
    db.session.add(novo_app)
    db.session.commit()
```

## 🔧 APIs Disponíveis

### Aplicativos
- `GET /api/apps` - Lista todos os aplicativos
- `GET /api/apps/<id>` - Detalhes de um aplicativo
- `POST /api/apps/<id>/download` - Registra download

### Comentários
- `GET /api/apps/<id>/comments` - Comentários de um app
- `POST /api/apps/<id>/comments` - Adiciona comentário

### Administração
- `POST /api/admin/login` - Login administrativo
- `POST /api/admin/logout` - Logout
- `GET /api/admin/stats` - Estatísticas

## 🎨 Personalização

### Cores e Temas
Edite `src/static/styles.css` para personalizar:
- Cores das abas do header
- Cores dos badges de categoria
- Gradientes do banner principal
- Esquema de cores geral

### Adicionando Categorias
1. Edite o HTML em `src/static/index.html`
2. Adicione nova seção de categoria
3. Configure cores no CSS
4. Atualize JavaScript para carregar apps da categoria

### Modificando Layout
O layout segue a estrutura do AN1.com:
- Header fixo com abas coloridas
- Banner principal dividido
- Seções de carrossel
- Categorias em blocos
- Footer simples

## 🔒 Segurança

### Implementadas
- Hash de senhas com Werkzeug
- Validação de entrada
- Proteção CSRF (básica)
- Sanitização de dados

### Recomendações para Produção
- Configurar HTTPS
- Usar variáveis de ambiente para senhas
- Implementar rate limiting
- Configurar firewall
- Backup regular do banco de dados

## 🐛 Solução de Problemas

### Erro de Porta em Uso
```bash
# Verificar processos na porta 5000
lsof -i :5000

# Matar processo se necessário
kill -9 <PID>
```

### Erro de Banco de Dados
```bash
# Recriar banco de dados
cd app-store
rm src/database/app.db
python -c "
from src.main import app
from src.models.user import db
with app.app_context():
    db.create_all()
"
```

### Problemas de Permissão
```bash
# Ajustar permissões
sudo chown -R appstore:appstore /home/appstore/app-store
chmod +x /home/appstore/app-store/src/main.py
```

## 📞 Suporte

Para suporte técnico ou dúvidas sobre implementação:
1. Verifique os logs: `sudo journalctl -u appstore -f`
2. Teste em modo debug: `python src/main.py`
3. Verifique configurações do Nginx: `sudo nginx -t`

## 🔄 Atualizações Futuras

### Funcionalidades Planejadas
- Sistema completo de upload de APKs
- Gerenciamento avançado de aplicativos via admin
- Sistema de usuários e favoritos
- Comentários com moderação
- Sistema de busca avançada
- Analytics e relatórios
- API para aplicativos móveis

### Melhorias de Performance
- Cache Redis
- CDN para assets
- Otimização de imagens
- Compressão gzip
- Lazy loading

---

**Desenvolvido com ❤️ replicando fielmente o design e funcionalidades do AN1.com**

