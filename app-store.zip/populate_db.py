#!/usr/bin/env python3
import sys
import os

# Adicionar o diretório raiz ao path
sys.path.insert(0, os.path.dirname(__file__))

from src.main import app
from src.models.user import db
from src.models.app import App
from src.models.admin import Admin
from src.models.comment import Comment
import json

def populate_database():
    """Popular o banco de dados com dados de exemplo"""
    
    # Inicializar o contexto do Flask
    with app.app_context():
        
        # Criar administrador padrão
        admin = Admin.query.filter_by(username='admin').first()
        if not admin:
            admin = Admin(
                username='admin',
                email='admin@appstore.com'
            )
            admin.set_password('admin123')
            db.session.add(admin)
            print("Administrador padrão criado: admin / admin123")
        
        # Verificar se já existem aplicativos
        if App.query.count() == 0:
            # Criar aplicativos de exemplo
            apps_data = [
                {
                    'name': 'PhotoEditor Pro',
                    'description': 'Editor de fotos profissional com recursos avançados de edição, filtros e efeitos especiais. Perfeito para fotógrafos e designers.',
                    'version': '2.1.0',
                    'category': 'Fotografia',
                    'download_url': 'https://example.com/downloads/photoeditor-pro.zip',
                    'icon_url': 'https://via.placeholder.com/128x128/4285f4/ffffff?text=PE',
                    'screenshots': ['https://via.placeholder.com/400x600/f0f0f0/333?text=Screenshot+1', 'https://via.placeholder.com/400x600/f0f0f0/333?text=Screenshot+2'],
                    'featured': True
                },
                {
                    'name': 'TaskManager',
                    'description': 'Gerenciador de tarefas simples e eficiente para organizar sua produtividade diária. Inclui lembretes e categorização.',
                    'version': '1.5.2',
                    'category': 'Produtividade',
                    'download_url': 'https://example.com/downloads/taskmanager.zip',
                    'icon_url': 'https://via.placeholder.com/128x128/34a853/ffffff?text=TM',
                    'screenshots': ['https://via.placeholder.com/400x600/f0f0f0/333?text=Tasks+View', 'https://via.placeholder.com/400x600/f0f0f0/333?text=Calendar+View'],
                    'featured': False
                },
                {
                    'name': 'MusicPlayer Plus',
                    'description': 'Player de música com qualidade de áudio superior, equalizer avançado e suporte a múltiplos formatos de arquivo.',
                    'version': '3.0.1',
                    'category': 'Música',
                    'download_url': 'https://example.com/downloads/musicplayer-plus.zip',
                    'icon_url': 'https://via.placeholder.com/128x128/ea4335/ffffff?text=MP',
                    'screenshots': ['https://via.placeholder.com/400x600/f0f0f0/333?text=Player+Interface', 'https://via.placeholder.com/400x600/f0f0f0/333?text=Equalizer'],
                    'featured': True
                },
                {
                    'name': 'CodeEditor Lite',
                    'description': 'Editor de código leve com syntax highlighting para múltiplas linguagens de programação. Ideal para desenvolvedores.',
                    'version': '1.8.0',
                    'category': 'Desenvolvimento',
                    'download_url': 'https://example.com/downloads/codeeditor-lite.zip',
                    'icon_url': 'https://via.placeholder.com/128x128/fbbc04/ffffff?text=CE',
                    'screenshots': ['https://via.placeholder.com/400x600/f0f0f0/333?text=Code+View', 'https://via.placeholder.com/400x600/f0f0f0/333?text=File+Explorer'],
                    'featured': False
                },
                {
                    'name': 'FitnessTracker',
                    'description': 'Aplicativo completo para acompanhamento de exercícios, dieta e progresso físico. Inclui planos de treino personalizados.',
                    'version': '2.3.1',
                    'category': 'Saúde',
                    'download_url': 'https://example.com/downloads/fitnesstracker.zip',
                    'icon_url': 'https://via.placeholder.com/128x128/ff6d01/ffffff?text=FT',
                    'screenshots': ['https://via.placeholder.com/400x600/f0f0f0/333?text=Dashboard', 'https://via.placeholder.com/400x600/f0f0f0/333?text=Workout+Plan'],
                    'featured': True
                }
            ]
            
            for app_data in apps_data:
                app_obj = App(
                    name=app_data['name'],
                    description=app_data['description'],
                    version=app_data['version'],
                    category=app_data['category'],
                    download_url=app_data['download_url'],
                    icon_url=app_data['icon_url'],
                    screenshots=json.dumps(app_data['screenshots']),
                    featured=app_data['featured'],
                    downloads_count=0
                )
                db.session.add(app_obj)
            
            print(f"Criados {len(apps_data)} aplicativos de exemplo")
        
        # Criar alguns comentários de exemplo
        if Comment.query.count() == 0:
            apps = App.query.all()
            if apps:
                comments_data = [
                    {
                        'app_id': apps[0].id,
                        'author_name': 'João Silva',
                        'author_email': 'joao@email.com',
                        'content': 'Excelente aplicativo! Muito fácil de usar e com ótimos recursos.',
                        'rating': 5
                    },
                    {
                        'app_id': apps[0].id,
                        'author_name': 'Maria Santos',
                        'author_email': 'maria@email.com',
                        'content': 'Bom app, mas poderia ter mais filtros disponíveis.',
                        'rating': 4
                    },
                    {
                        'app_id': apps[1].id,
                        'author_name': 'Pedro Costa',
                        'author_email': 'pedro@email.com',
                        'content': 'Perfeito para organizar minhas tarefas diárias. Recomendo!',
                        'rating': 5
                    }
                ]
                
                for comment_data in comments_data:
                    comment = Comment(
                        app_id=comment_data['app_id'],
                        author_name=comment_data['author_name'],
                        author_email=comment_data['author_email'],
                        content=comment_data['content'],
                        rating=comment_data['rating'],
                        approved=True
                    )
                    db.session.add(comment)
                
                print(f"Criados {len(comments_data)} comentários de exemplo")
        
        # Salvar todas as mudanças
        db.session.commit()
        print("Banco de dados populado com sucesso!")

if __name__ == '__main__':
    populate_database()

