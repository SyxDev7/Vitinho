# 🔐 Credenciais e Informações de Acesso

## 👨‍💼 Painel Administrativo

### Credenciais de Login
- **URL**: http://localhost:5000 (clique em "Admin" no menu)
- **Usuário**: `admin`
- **Senha**: `admin123`

### Funcionalidades Disponíveis
- ✅ Login seguro com hash de senhas
- ✅ Estatísticas do sistema (apps, downloads, comentários)
- ✅ Interface administrativa básica
- 🔄 Gerenciamento completo de apps (em desenvolvimento)

## 🗄️ Banco de Dados

### Localização
- **Arquivo**: `src/database/app.db`
- **Tipo**: SQLite
- **Backup**: Recomendado fazer backup regular

### Dados de Exemplo Incluídos
- **3 aplicativos**: Flight Pilot, Idle Miner Tycoon, War Robots
- **1 administrador**: admin/admin123
- **Categorias**: Simulação, Ação
- **Screenshots**: Placeholders configurados

## 🌐 URLs e Endpoints

### Site Principal
- **Homepage**: http://localhost:5000
- **API Apps**: http://localhost:5000/api/apps
- **API Admin**: http://localhost:5000/api/admin/login

### Estrutura de URLs
```
/                           # Página principal (AN1 clone)
/api/apps                   # Lista todos os aplicativos
/api/apps/<id>              # Detalhes de um aplicativo específico
/api/apps/<id>/download     # Registra download do aplicativo
/api/apps/<id>/comments     # Comentários do aplicativo
/api/admin/login            # Login administrativo
/api/admin/logout           # Logout administrativo
/api/admin/stats            # Estatísticas do sistema
```

## 🔧 Configurações Técnicas

### Servidor Flask
- **Host**: 0.0.0.0 (aceita conexões externas)
- **Porta**: 5000 (padrão)
- **Debug**: Ativado em desenvolvimento
- **CORS**: Habilitado para todas as origens

### Banco de Dados
- **Engine**: SQLite
- **Localização**: src/database/app.db
- **Encoding**: UTF-8
- **Auto-commit**: Configurado

## 📊 Estatísticas Atuais

### Aplicativos
- **Total**: 3 apps de exemplo
- **Categorias**: Simulação (2), Ação (1)
- **Featured/MOD**: 2 apps marcados como destaque

### Sistema
- **Comentários**: 0 (sistema pronto para receber)
- **Downloads**: 0 (contador será incrementado com uso)
- **Administradores**: 1 (admin principal)

## 🔒 Segurança

### Senhas
- **Hash**: Werkzeug PBKDF2 SHA256
- **Salt**: Gerado automaticamente
- **Rounds**: Padrão seguro

### Recomendações para Produção
1. **Alterar senha padrão**:
   ```python
   from src.main import app
   from src.models.user import db
   from src.models.admin import Admin
   
   with app.app_context():
       admin = Admin.query.filter_by(username='admin').first()
       admin.set_password('nova_senha_segura')
       db.session.commit()
   ```

2. **Configurar variáveis de ambiente**:
   ```bash
   export FLASK_SECRET_KEY="chave_secreta_aleatoria"
   export DATABASE_URL="sqlite:///app.db"
   ```

3. **Configurar HTTPS** na produção

## 🚀 Deploy na VPS

### Informações para Deploy
- **Usuário recomendado**: appstore
- **Diretório**: /home/appstore/app-store
- **Servidor web**: Nginx + Gunicorn
- **Porta interna**: 5000
- **Porta externa**: 80/443

### Comandos Essenciais
```bash
# Iniciar aplicação
cd /home/appstore/app-store
source venv/bin/activate
python src/main.py

# Com Gunicorn (produção)
gunicorn --workers 3 --bind 0.0.0.0:5000 src.main:app

# Verificar status
sudo systemctl status appstore
sudo journalctl -u appstore -f
```

## 📝 Logs e Monitoramento

### Logs do Sistema
- **Flask**: Console output
- **Nginx**: /var/log/nginx/access.log
- **Systemd**: journalctl -u appstore

### Monitoramento Recomendado
- **Uptime**: Verificar se serviço está rodando
- **Espaço em disco**: Para banco de dados e uploads
- **Memória**: Uso do Python/Flask
- **CPU**: Carga do servidor

## 🔄 Backup e Restauração

### Backup do Banco de Dados
```bash
# Backup simples
cp src/database/app.db backup_$(date +%Y%m%d_%H%M%S).db

# Backup com dump SQL
sqlite3 src/database/app.db .dump > backup_$(date +%Y%m%d_%H%M%S).sql
```

### Restauração
```bash
# Restaurar arquivo .db
cp backup_YYYYMMDD_HHMMSS.db src/database/app.db

# Restaurar de dump SQL
sqlite3 src/database/app.db < backup_YYYYMMDD_HHMMSS.sql
```

## 🆘 Solução de Problemas

### Problemas Comuns

1. **Erro "Port already in use"**
   ```bash
   lsof -i :5000
   kill -9 <PID>
   ```

2. **Erro de banco de dados**
   ```bash
   rm src/database/app.db
   python -c "from src.main import app; from src.models.user import db; app.app_context().push(); db.create_all()"
   ```

3. **Erro de permissões**
   ```bash
   sudo chown -R appstore:appstore /home/appstore/app-store
   chmod +x src/main.py
   ```

### Contatos de Emergência
- **Logs**: `tail -f /var/log/nginx/error.log`
- **Status**: `systemctl status appstore nginx`
- **Reiniciar**: `sudo systemctl restart appstore nginx`

---

## 📞 Suporte Técnico

Para dúvidas ou problemas:
1. Verificar logs do sistema
2. Testar em modo debug
3. Verificar configurações de rede
4. Consultar documentação no README_NOVO.md

**⚠️ IMPORTANTE**: Altere as credenciais padrão antes de colocar em produção!

